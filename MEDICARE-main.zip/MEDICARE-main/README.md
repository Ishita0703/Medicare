# MEDICARE
AVISHKAR Project
![login](https://user-images.githubusercontent.com/81457490/147487613-2fdca379-ec55-426b-a4e2-d2616a64d883.jpg)
![login](https://user-images.githubusercontent.com/81457490/147487624-1a44a731-6d31-4064-8d79-fd519a187b01.jpg)
![login](https://user-images.githubusercontent.com/81457490/147487618-a74777e8-07e6-40ca-b44b-ab3182884a8d.jpg)
![signup](https://user-images.githubusercontent.com/81457490/147487645-cc20548d-5f00-4b1d-a87c-32db839facb3.jpg)
![signup](https://user-images.githubusercontent.com/81457490/147487655-5bbefd61-113b-449e-bc30-05bc8232f923.jpg)


## Login - Signup - Logout

Here we have used PHP for backend with MySql database and bootstrap library for frontend. We have also used a hashing algorithm which is  providing our database safety from hackers.
Along with this we do not allow two users to be able to sign in using the same username. It will give errors. 
We are planning to add an appointment page instead of a welcome page which is under process. The page will allow users to maintain a profile page as well as appointment time will be shown to the users whenever doctor will be ready to take appointment.

![update](https://user-images.githubusercontent.com/81457490/147486211-9609fdd8-7045-49f1-8c5b-24240f9c150e.jpg)
![chatapp](https://user-images.githubusercontent.com/81457490/147486213-00de2259-a04b-4979-8ecc-85c4623c79b1.jpg)
![schedule](https://user-images.githubusercontent.com/81457490/147486217-39f5c8f3-1ed0-4310-a9ca-68bc6509f5d0.jpg)

## Important updates
## Chat App
## Schedule Planner

These section as their name suggests the important updates section help doctor to keep important notes about specefic patient to himself so that he can reconsider it at the time of next appointment. The chat app section is a place where doctor and patient can interact. The Schedule planner side will help patient and doctor to schedule their day efficiently.

![Infosite](https://user-images.githubusercontent.com/81457490/147485559-651f485c-f248-426a-bb8b-cf415fed32d4.png)
![Infosite](https://user-images.githubusercontent.com/81457490/147485566-8aa75030-35e8-4025-ade3-d3cd1de9516c.png)

## Disease Infosite

This section is still incomplete and needs a lot of work , we are planning to create a page where user can visit and can get the basic knowledge about different type of disease. This is just the basic idea of the original page we wanted to create.

